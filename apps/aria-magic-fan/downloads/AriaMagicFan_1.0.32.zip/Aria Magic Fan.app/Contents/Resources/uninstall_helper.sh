#!/bin/bash
# Aria Magic Fan 风扇助手 · 卸载脚本（需要管理员权限）
# 2026-09-29 · Claude 200_MacFan · claude-sonnet-5-5 · v1.0.0
# 2026-09-30 · 1.0.15：App 改名 Aria Mac Fan，提示里的名字和路径跟着改。
# 2026-10-01 · 1.0.17：改名 Aria Magic Fan / Aria魔法散热风扇，提示里的名字和路径跟着改。
#
# 谁来跑：Aria Magic Fan 设置 → 通用 → “停用风扇控制…”，由系统弹出密码框；
#         或者你自己在终端里：  sudo bash "/Applications/Aria Magic Fan.app/Contents/Resources/uninstall_helper.sh"（旧版路径是 /Applications/Aria Mac Fan.app/… 或 /Applications/Mac Fan.app/…）
# 做了什么：卸载 launchd 任务（助手收到 SIGTERM 会先把风扇交还系统），再移除安装时放进去的两个文件。
#   /Library/LaunchDaemons/com.harrywood.macfan.helper.plist
#   /Library/PrivilegedHelperTools/com.harrywood.macfan.helper
# 助手日志 /var/log/com.harrywood.macfan.helper.log 不动，留给你排查。
set -uo pipefail

LABEL="com.harrywood.macfan.helper"

if [ "$(id -u)" != "0" ]; then
  echo "需要管理员权限（请用 sudo 运行，或在 Aria Magic Fan 里点“停用风扇控制…”）"
  exit 1
fi

/bin/launchctl bootout "system/$LABEL" 2>/dev/null || true
/bin/rm -f "/Library/LaunchDaemons/$LABEL.plist" "/Library/PrivilegedHelperTools/$LABEL"

echo "OK · 风扇助手已卸载"
