#!/bin/bash
# Aria Magic Fan 风扇助手 · 安装脚本（需要管理员权限）
# 2026-09-29 · Claude 200_MacFan · claude-sonnet-5-5 · v1.0.0
# 2026-09-30 · 1.0.15：App 改名 Aria Mac Fan，提示里的名字和路径跟着改；助手认新旧两个路径（Aria Mac Fan.app / Mac Fan.app）。
# 2026-10-01 · 1.0.17：改名 Aria Magic Fan / Aria魔法散热风扇；助手认三个路径（Aria Magic Fan.app / Aria Mac Fan.app / Mac Fan.app）。
#
# 谁来跑：Aria Magic Fan 里点“启用风扇控制…”，由系统弹出密码框，用管理员权限跑本脚本；
#         或者你自己在终端里：  sudo bash "/Applications/Aria Magic Fan.app/Contents/Resources/install_helper.sh"
# 做了什么（只有这三件事，卸载见 uninstall_helper.sh）：
#   1. 把助手程序复制到  /Library/PrivilegedHelperTools/com.harrywood.macfan.helper   （root:wheel，755）
#   2. 写入 launchd 配置  /Library/LaunchDaemons/com.harrywood.macfan.helper.plist       （root:wheel，644）
#   3. 让 launchd 加载它（按需拉起：有人连接才运行，空闲 8 秒自己退出；不开机自启常驻）
# 助手做什么：只写风扇的 模式 / 目标转速（转速夹在 [系统最低, 硬件最高]），
#             App 退出 / 崩溃 / 15 秒没心跳都会把风扇交还系统自动控制。日志：/var/log/com.harrywood.macfan.helper.log
set -euo pipefail

LABEL="com.harrywood.macfan.helper"
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/../Library/LaunchServices/$LABEL"
DEST_BIN="/Library/PrivilegedHelperTools/$LABEL"
DEST_PLIST="/Library/LaunchDaemons/$LABEL.plist"

if [ "$(id -u)" != "0" ]; then
  echo "需要管理员权限（请用 sudo 运行，或在 Aria Magic Fan 里点“启用风扇控制…”）"
  exit 1
fi
if [ ! -f "$SRC" ]; then
  echo "找不到助手程序：$SRC"
  exit 1
fi
if [ ! -d "/Applications/Aria Magic Fan.app" ] && [ ! -d "/Applications/Aria Mac Fan.app" ] && [ ! -d "/Applications/Mac Fan.app" ]; then
  echo "提示：助手只接受 /Applications/Aria Magic Fan.app（旧版是 Aria Mac Fan.app / Mac Fan.app）里的 App 连接，请先把 Aria Magic Fan 放进“应用程序”文件夹。"
fi

# 先停掉旧版本（没装过会报错，忽略）
/bin/launchctl bootout "system/$LABEL" 2>/dev/null || true

/bin/mkdir -p /Library/PrivilegedHelperTools
/usr/bin/install -o root -g wheel -m 755 "$SRC" "$DEST_BIN"

/bin/cat > "$DEST_PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Label</key>
	<string>$LABEL</string>
	<key>ProgramArguments</key>
	<array>
		<string>$DEST_BIN</string>
	</array>
	<key>MachServices</key>
	<dict>
		<key>$LABEL</key>
		<true/>
	</dict>
	<key>RunAtLoad</key>
	<false/>
	<key>KeepAlive</key>
	<false/>
</dict>
</plist>
PLIST
/usr/sbin/chown root:wheel "$DEST_PLIST"
/bin/chmod 644 "$DEST_PLIST"

/bin/launchctl enable "system/$LABEL" 2>/dev/null || true
/bin/launchctl bootstrap system "$DEST_PLIST"

echo "OK · 风扇助手已安装并由 launchd 接管（按需拉起）"
